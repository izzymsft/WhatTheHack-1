## Setting up the Kubernetes Cluster

The directions for setting up the Kubernetes cluster is available [here](../README.md)